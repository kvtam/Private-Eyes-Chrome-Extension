# Private-Eyes-Chrome-Extension
/////Author's Notes
A chrome extension I made to automate filling out the forms please edit it as you need and branch or update the repo.
However, please keep the vulpix as the icon, it's cute.

/////Instructions
  1. Download the repo as a zip file or use a bash terminal to clone the repo

  2.Go to your Extension settings in Chrome and set it to developer mode in the top right corner of the screen.
  
  3.In the top left corner select the leftmost button "Load Unpacked", select the Extension folder in Private-Eyes-Chrome_Extension/PE autofiller/ 
  
  4.Now when you are on the new site edit the name field to your judgement and hit the Vulpix icon to execute the script
  
  5.The title field to the EN_description field should be filled in. You may need to edit the fields to make sure they make sense so double check.

  	5a. As of version 0.2 edits the Case field but needs more input to work for more phrases.
  
  6.Does not edit any other fields at the moment but anticipate this for a future update.
  
/////Future Ideas

  1. Get it to translate automatically using the DeepL API
  
  
